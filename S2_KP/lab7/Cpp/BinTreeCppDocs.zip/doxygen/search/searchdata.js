var indexSectionsWithContent =
{
  0: "bdilmnprsv~",
  1: "bn",
  2: "b",
  3: "bdimnps~",
  4: "lrv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

