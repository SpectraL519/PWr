var searchData=
[
  ['right_0',['right',['../class_node.html#ad7092450d89448320103cde1f72da320',1,'Node']]],
  ['root_1',['root',['../class_binary_tree.html#a2db40f59d96afceb1a005e6d9aef2374',1,'BinaryTree']]]
];
